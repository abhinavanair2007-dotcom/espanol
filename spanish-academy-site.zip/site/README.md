# Academia de Español – deploy guide

Files: index.html (the whole site), netlify/functions/ai.js (Netlify AI proxy), api/ai.js (Vercel AI proxy), netlify.toml.

The site works without AI. The AI tutor, AI video search, AI-generated tests and the Malayalam explanations need an Anthropic API key (console.anthropic.com), stored as the environment variable ANTHROPIC_API_KEY.

## Netlify
1. Push this folder to a GitHub repository (or use the Netlify CLI: `npm i -g netlify-cli`, then `netlify deploy --prod` in this folder).
2. Netlify > Add new site > Import from Git, pick the repo. Leave the build command empty.
3. Site configuration > Environment variables > add ANTHROPIC_API_KEY, then redeploy.
(Dragging only index.html onto app.netlify.com/drop gives the site without AI.)

## Vercel
1. Push the folder to GitHub, then Vercel > Add New > Project > import the repo (Framework: Other, no build command). Or run `npx vercel --prod` in this folder.
2. Settings > Environment Variables > add ANTHROPIC_API_KEY, then redeploy.

## Notes
- Logins are stored in each visitor's browser only (demo). Real shared accounts need a database/auth service.
- /api/ai is public: set a spending limit on your API key, and consider rate limiting before sharing widely.
