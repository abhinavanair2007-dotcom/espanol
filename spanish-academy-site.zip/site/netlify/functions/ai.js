// Netlify Function: proxies AI requests to Anthropic. Needs env var ANTHROPIC_API_KEY.
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };
  try {
    const { prompt } = JSON.parse(event.body || "{}");
    if (!prompt || typeof prompt !== "string" || prompt.length > 12000)
      return { statusCode: 400, body: JSON.stringify({ error: "bad prompt" }) };
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 1500, messages: [{ role: "user", content: prompt }] })
    });
    const d = await r.json();
    const text = (d.content || []).map(b => b.text || "").join("");
    return { statusCode: r.ok ? 200 : 502, headers: { "content-type": "application/json" }, body: JSON.stringify({ text }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: "server" }) };
  }
};
